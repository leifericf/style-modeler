# Examples (en)

Evidence snippets are PII-redacted where needed and contain no source references.

## Register / emphasis
### Claim: Uses ALL CAPS for emphasis on key words/phrases.
- "The 75,000,000 great American Patriots who voted for me, AMERICA FIRST, and MAKE AMERICA GREAT AGAIN, will have a GIANT VOICE long into the future. They will not be disrespected or treated unfairly in any way, shape or form!!!"
- "Pelosi & Schumer have no interest in making a deal that is good for our Country and our People. All they want is a trillion dollars, and much more, for their Radical Left Governed States, most of which are doing very badly. It is called..."
- "Hard to believe, but if Nancy Pelosi had put our great Trade Deal with Mexico and Canada, USMCA, up for a vote long ago, our economy would be even better. If she doesn’t move quickly, it will collapse!"
- "Watching final hole of [REDACTED_HANDLE]. [REDACTED_HANDLE] is looking GREAT!"
- "Now that the Witch Hunt has given up on Russia and is looking at the rest of the World, they should easily be able to take it into the Mid-Term Elections where they can put some hurt on the Republican Party. Don’t worry about Dems FISA A..."

### Claim: Leans on exclamation marks for intensity and urgency.
- "The 75,000,000 great American Patriots who voted for me, AMERICA FIRST, and MAKE AMERICA GREAT AGAIN, will have a GIANT VOICE long into the future. They will not be disrespected or treated unfairly in any way, shape or form!!!"
- "Minnesota, we need Lacy Johnson in Washington, D.C. Has my Complete and Total Endorsement. He’s tough and smart - and loves Minnesota. Look at the MESS you just went through - No more. Next time call up the National Guard much sooner, an..."
- "The three year Hoax continues! [REDACTED_URL]"
- "The cost of ObamaCare is far too high for our great citizens. The deductibles, in many cases way over $7000, make it almost worthless or unusable. Good things are going to happen! [REDACTED_HANDLE]  [REDACTED_HANDLE] [REDACTED_HANDLE]  [..."
- "Today, it was my great honor to welcome the 2017 NCAA Football National Champion, Alabama Crimson Tide - to the White House. Congratulations! #RollTide[REDACTED_URL] [REDACTED_URL]"

## Stance & questions
### Claim: Uses questions (often rhetorical) to challenge or frame a point.
- "Looks like they are setting up a big “voter dump” against the Republican candidates. Waiting to see how many votes they need?"
- "Why should Crazy Nancy Pelosi, just because she has a slight majority in the House, be allowed to Impeach the President of the United States? Got ZERO Republican votes, there was no crime, the call with Ukraine was perfect, with “no pres..."
- "....terrible Gang of Angry Democrats. Look at their past, and look where they come from. The now $30,000,000 Witch Hunt continues and they’ve got nothing but ruined lives. Where is the Server? Let these terrible people go back to the Cli..."
- "After Crooked [REDACTED_HANDLE] allowed ISIS to rise, she now claims she'll defeat them? LAUGHABLE! Here's my plan: [REDACTED_URL]"
- "Shouldn’t George Will have to give a disclaimer every time he is on Fox that his wife works for Scott Walker?"

### Claim: Uses boosters/intensifiers ("very/really/absolutely/never/always") to heighten certainty.
- "The States want to redo their votes. They found out they voted on a FRAUD. Legislatures never approved. Let them do it. BE STRONG!"
- "I always stand with leaders who weren’t afraid to stand early with me. That’s why I am supporting a true conservative, [REDACTED_HANDLE] for State Treasurer of North Dakota! [REDACTED_URL]"
- "....Don't the Europeans have a lot of responsibility?” [REDACTED_HANDLE] Thank you Katie, I offered ISIS prisoners to the European countries from where they came, and was rejected on numerous occasions. They probably figured that the U.S..."
- "I never offered Pardons to Homeland Security Officials, never ordered anyone to close our Southern Border (although I have the absolute right to do so, and may if Mexico does not apprehend the illegals coming to our Border), and am not “..."
- "Harley-Davidson should stay 100% in America, with the people that got you your success. I’ve done so much for you, and then this. Other companies are coming back where they belong! We won’t forget, and neither will your customers or your..."

### Claim: Occasionally hedges with softeners ("maybe/perhaps/probably") when speculating.
- "Something how Dr. Fauci is revered by the LameStream Media as such a great professional, having done, they say, such an incredible job, yet he works for me and the Trump Administration, and I am in no way given any credit for my work. Ge..."
- "Do Nothing Democrats were busy wasting their time on the Impeachment Hoax, & anything they could do to make the Republican Party look bad, while I was busy calling early boarder & flight closings, putting us way ahead in our battle with..."
- "The E.U. and China will further lower interest rates and pump money into their systems, making it much easier for their manufacturers to sell product. In the meantime, and with very low inflation, our Fed does nothing - and probably will..."
- "The Paris Agreement isn’t working out so well for Paris. Protests and riots all over France. People do not want to pay large sums of money, much to third world countries (that are questionably run), in order to maybe protect the environm..."
- "Art Laffer just said that he doesn't know how a Democrat could vote against the big tax cut/reform bill and live with themselves!  [REDACTED_HANDLE]"

## Cohesion & framing
### Claim: Uses contrast markers ("but/however/yet") to pivot or reframe.
- "These scoundrels are only toying with the [REDACTED_HANDLE] (a great guy) vote. Just didn’t want to announce quite yet. They’ve got as many ballots as are necessary. Rigged Election!"
- "There is tremendous CoronaVirus testing capacity in Washington for the Senators returning to Capital Hill on Monday. Likewise the House, which should return but isn’t because of Crazy Nancy P. The 5 minute Abbott Test will be used. Pleas..."
- "Now the press is trying to sell the fact that I wanted a Moat stuffed with alligators and snakes, with an electrified fence and sharp spikes on top, at our Southern Border. I may be tough on Border Security, but not that tough. The press..."
- "Bernie Sanders and wife should pay the Pre-Trump Taxes on their almost $600,000 in income. He is always complaining about these big TAX CUTS, except when it benefits him. They made a fortune off of Trump, but so did everyone else - and t..."
- "Congress must pass smart, fast and reasonable Immigration Laws now. Law Enforcement at the Border is doing a great job, but the laws they are forced to work with are insane. When people, with or without children, enter our Country, they..."

### Claim: Sometimes opens with a connector ("But/So/Because/Now") to continue a thread.
- "So true. Thanks Josh! [REDACTED_URL]"
- "Now Fake News [REDACTED_HANDLE] is actually reporting that I wanted my daughter, Ivanka, to run with me as my Vice President in 2016 Election. Wrong and totally ridiculous. These people are sick!"
- "So nice to see this great honor. Thank you (but haven’t played golf in a long time)! [REDACTED_URL]"
- "So Great! [REDACTED_URL]"
- "So sorry to hear about the terrible accident involving our GREAT West Point Cadets. We mourn the loss of life and pray for the injured. God Bless them ALL!"

## Audience & calls-to-action
### Claim: Direct address to the reader ("you/your") is common in persuasive lines.
- "I am asking for everyone at the U.S. Capitol to remain peaceful. No violence! Remember, WE are the Party of Law & Order – respect the Law and our great men and women in Blue. Thank you!"
- "The Fake and Corrupt News never called Google. They said this was not true. Even in times such as these, they are not truthful. Watch for their apology, it won’t happen. More importantly, thank you to Google! [REDACTED_URL]"
- "Hans Von Spakovsky, “I haven’t seen any evidence of actual violations of the law, which is usually a basis before you start an investigation. Adam Schiff seems to be copying Joseph McCarthy in wanting to open up investigations when they..."
- "Thank you to my great supporters in Wisconsin. I heard that the crowd and enthusiasm was unreal!"
- """"[REDACTED_HANDLE]: [REDACTED_HANDLE] By going after you, Jindal also lost the LA governor race! Politicians Beware.""

### Claim: Closes with CTA-style phrasing (thanks/please/let me know) or a prompting question.
- "I am asking for everyone at the U.S. Capitol to remain peaceful. No violence! Remember, WE are the Party of Law & Order – respect the Law and our great men and women in Blue. Thank you!"
- "The great people of Montana can have no better VOICE than Senator [REDACTED_HANDLE]. He is doing an incredible job! Whoever the Democrat nominee may be, please understand that I will be working hard with Steve all the way, & last night I..."
- "Very important that OPEC increase the flow of Oil. World Markets are fragile, price of Oil getting too high. Thank you!"
- "Crimea was TAKEN by Russia during the Obama Administration. Was Obama too soft on Russia?"
- "THANK YOU Arkansas! Get out &amp, #VoteTrump on Tuesday. We will MAKE AMERICA SAFE &amp, GREAT AGAIN! [REDACTED_URL]"

## Structure
### Claim: Rarely uses explicit list formatting (when present, it is a deliberate rhetorical move).
- "7. The badly flawed Paris Climate Agreement protects the polluters, hurts Americans, and cost a fortune. NOT ON MY WATCH!8. I want crystal clean water and the cleanest and the purest air on the planet – we’ve now got that!"
- "6. The Democrats’ destructive “environmental” proposals will raise your energy bill and prices at the pump. Don't the Democrats care about fighting American poverty?"
- "4. The U.S. now leads the world in energy production...BUT... 5. Who's got the world's cleanest and safest air and water? AMERICA!"
- "1. Which country has the largest carbon emission reduction?AMERICA!2. Who has dumped the most carbon into the air?   CHINA!3. 91% of the world’s population are exposed to air pollution above the World Health Organization’s suggested leve..."
- "3.  You should tweet your pick for MVP using the celebrity’s name followed by the hashtag #CelebApprenticeMVP."

